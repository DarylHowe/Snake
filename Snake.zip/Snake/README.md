SNAKE
=====
 * Author @ Daryl Howe 30/05/2020
 * Contact - howedaryl@hotmail.com


Description
============
The traditional phone game 'SNAKE' re-created in JAVA.

Instructions
============ 
Use the following link to install the application onto an Android mobile device.
* https://play.google.com/store/apps/details?id=com.DarylHoweDevs.PerfectEgg

A self driven project and was chosen as a way to learn about game development in JAVA. 